--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.slitlamps DROP CONSTRAINT slitlamps_pkey;
ALTER TABLE ONLY public.patients DROP CONSTRAINT patients_pkey;
ALTER TABLE ONLY public.patient_user_defined_fields DROP CONSTRAINT patient_user_defined_fields_pkey;
ALTER TABLE ONLY public.patient_user_defined_data DROP CONSTRAINT patient_user_defined_data_pkey;
ALTER TABLE ONLY public.mandatory_fields DROP CONSTRAINT mandatory_fields_pkey;
ALTER TABLE ONLY public.images DROP CONSTRAINT images_pkey;
ALTER TABLE ONLY public.file_upolads DROP CONSTRAINT file_upolads_pkey;
ALTER TABLE ONLY public.devices DROP CONSTRAINT devices_pkey;
ALTER TABLE ONLY public.automated_db_backups DROP CONSTRAINT automated_db_backups_pkey;
ALTER TABLE ONLY public.audits DROP CONSTRAINT audits_pkey;
ALTER TABLE ONLY public.audit_logs DROP CONSTRAINT audit_logs_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.slitlamps ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.patients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.patient_user_defined_fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.patient_user_defined_data ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.mandatory_fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.file_upolads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.devices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.automated_db_backups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.audits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.audit_logs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.slitlamps_id_seq;
DROP TABLE public.slitlamps;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.patients_id_seq;
DROP TABLE public.patients;
DROP SEQUENCE public.patient_user_defined_fields_id_seq;
DROP TABLE public.patient_user_defined_fields;
DROP SEQUENCE public.patient_user_defined_data_id_seq;
DROP TABLE public.patient_user_defined_data;
DROP SEQUENCE public.mandatory_fields_id_seq;
DROP TABLE public.mandatory_fields;
DROP SEQUENCE public.images_id_seq;
DROP TABLE public.images;
DROP SEQUENCE public.file_upolads_id_seq;
DROP TABLE public.file_upolads;
DROP SEQUENCE public.devices_id_seq;
DROP TABLE public.devices;
DROP SEQUENCE public.automated_db_backups_id_seq;
DROP TABLE public.automated_db_backups;
DROP SEQUENCE public.audits_id_seq;
DROP TABLE public.audits;
DROP SEQUENCE public.audit_logs_id_seq;
DROP TABLE public.audit_logs;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE audit_logs (
    id integer NOT NULL,
    audit_id integer,
    record_id character varying(255),
    old_data character varying(255),
    new_data character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE audit_logs_id_seq OWNED BY audit_logs.id;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('audit_logs_id_seq', 22, true);


--
-- Name: audits; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE audits (
    id integer NOT NULL,
    record_id character varying(255),
    record_type character varying(255),
    date timestamp without time zone,
    ip character varying(255),
    action character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.audits OWNER TO postgres;

--
-- Name: audits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audits_id_seq OWNER TO postgres;

--
-- Name: audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE audits_id_seq OWNED BY audits.id;


--
-- Name: audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('audits_id_seq', 314, true);


--
-- Name: automated_db_backups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE automated_db_backups (
    id integer NOT NULL,
    "time" character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.automated_db_backups OWNER TO postgres;

--
-- Name: automated_db_backups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE automated_db_backups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.automated_db_backups_id_seq OWNER TO postgres;

--
-- Name: automated_db_backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE automated_db_backups_id_seq OWNED BY automated_db_backups.id;


--
-- Name: automated_db_backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('automated_db_backups_id_seq', 1, true);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE devices (
    id integer NOT NULL,
    device_name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.devices OWNER TO postgres;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO postgres;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE devices_id_seq OWNED BY devices.id;


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('devices_id_seq', 13, true);


--
-- Name: file_upolads; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE file_upolads (
    id integer NOT NULL,
    db_file character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.file_upolads OWNER TO postgres;

--
-- Name: file_upolads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE file_upolads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.file_upolads_id_seq OWNER TO postgres;

--
-- Name: file_upolads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE file_upolads_id_seq OWNED BY file_upolads.id;


--
-- Name: file_upolads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('file_upolads_id_seq', 9, true);


--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE images (
    id integer NOT NULL,
    patientid character varying(255),
    imageid integer,
    datetime timestamp without time zone,
    od_os character varying(255),
    equipinfo character varying(255),
    description character varying(255),
    celldensity character varying(255),
    meancellarea character varying(255),
    imagebuffer character varying(255),
    title character varying(255),
    disease character varying(255),
    cddelta character varying(255),
    cv character varying(255),
    hexagonality character varying(255),
    analysed character varying(255),
    location character varying(255),
    imagefilename character varying(255),
    is_delete boolean DEFAULT false,
    db integer DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE images_id_seq OWNED BY images.id;


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('images_id_seq', 1, false);


--
-- Name: mandatory_fields; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE mandatory_fields (
    id integer NOT NULL,
    fields character varying(255),
    is_mandatory boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.mandatory_fields OWNER TO postgres;

--
-- Name: mandatory_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mandatory_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mandatory_fields_id_seq OWNER TO postgres;

--
-- Name: mandatory_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mandatory_fields_id_seq OWNED BY mandatory_fields.id;


--
-- Name: mandatory_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mandatory_fields_id_seq', 21, true);


--
-- Name: patient_user_defined_data; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE patient_user_defined_data (
    id integer NOT NULL,
    patient_id integer,
    field_name character varying(255),
    data character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.patient_user_defined_data OWNER TO postgres;

--
-- Name: patient_user_defined_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE patient_user_defined_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patient_user_defined_data_id_seq OWNER TO postgres;

--
-- Name: patient_user_defined_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE patient_user_defined_data_id_seq OWNED BY patient_user_defined_data.id;


--
-- Name: patient_user_defined_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('patient_user_defined_data_id_seq', 1, false);


--
-- Name: patient_user_defined_fields; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE patient_user_defined_fields (
    id integer NOT NULL,
    field_name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.patient_user_defined_fields OWNER TO postgres;

--
-- Name: patient_user_defined_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE patient_user_defined_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patient_user_defined_fields_id_seq OWNER TO postgres;

--
-- Name: patient_user_defined_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE patient_user_defined_fields_id_seq OWNED BY patient_user_defined_fields.id;


--
-- Name: patient_user_defined_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('patient_user_defined_fields_id_seq', 1, true);


--
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE patients (
    id integer NOT NULL,
    patientid character varying(255),
    sex character varying(255),
    ssn character varying(255),
    birthdate timestamp without time zone,
    namefirst character varying(255),
    namem character varying(255),
    namelast character varying(255),
    race character varying(255),
    bloodtype character varying(255),
    addressstreet character varying(255),
    addresstown character varying(255),
    addressstate character varying(255),
    addresszip character varying(255),
    addresscountry character varying(255),
    telenumber character varying(255),
    oculardiag character varying(255),
    medicaldiag character varying(255),
    firstvisitdate timestamp without time zone,
    comments character varying(255),
    is_delete boolean DEFAULT false,
    db integer DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE patients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_id_seq OWNER TO postgres;

--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE patients_id_seq OWNED BY patients.id;


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('patients_id_seq', 16, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: slitlamps; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE slitlamps (
    id integer NOT NULL,
    patient_id integer,
    patientid character varying(255),
    imageid integer,
    datetime timestamp without time zone,
    od_os character varying(255),
    equipinfo character varying(255),
    description character varying(255),
    celldensity character varying(255),
    meancellarea character varying(255),
    imagebuffer character varying(255),
    title character varying(255),
    disease character varying(255),
    cddelta character varying(255),
    cv character varying(255),
    hexagonality character varying(255),
    analysed character varying(255),
    location character varying(255),
    imagefilename character varying(255),
    is_delete boolean DEFAULT false,
    db integer DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    pimage_file_name character varying(255),
    pimage_content_type character varying(255),
    pimage_file_size integer
);


ALTER TABLE public.slitlamps OWNER TO postgres;

--
-- Name: slitlamps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE slitlamps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.slitlamps_id_seq OWNER TO postgres;

--
-- Name: slitlamps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE slitlamps_id_seq OWNED BY slitlamps.id;


--
-- Name: slitlamps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('slitlamps_id_seq', 37, true);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying(255),
    password character varying(255),
    type character varying(255),
    auth_type character varying(255) DEFAULT 'user'::character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_seq', 2, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY audit_logs ALTER COLUMN id SET DEFAULT nextval('audit_logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY audits ALTER COLUMN id SET DEFAULT nextval('audits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY automated_db_backups ALTER COLUMN id SET DEFAULT nextval('automated_db_backups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY devices ALTER COLUMN id SET DEFAULT nextval('devices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY file_upolads ALTER COLUMN id SET DEFAULT nextval('file_upolads_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY images ALTER COLUMN id SET DEFAULT nextval('images_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mandatory_fields ALTER COLUMN id SET DEFAULT nextval('mandatory_fields_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY patient_user_defined_data ALTER COLUMN id SET DEFAULT nextval('patient_user_defined_data_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY patient_user_defined_fields ALTER COLUMN id SET DEFAULT nextval('patient_user_defined_fields_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY patients ALTER COLUMN id SET DEFAULT nextval('patients_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY slitlamps ALTER COLUMN id SET DEFAULT nextval('slitlamps_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY audit_logs (id, audit_id, record_id, old_data, new_data, created_at, updated_at) FROM stdin;
1	31	10	--- []\n	--- []\n	2012-09-05 10:28:12.626828	2012-09-05 10:28:12.626828
2	38	13	---\n- addresscountry\n- \n- addressstate\n- \n- addressstreet\n- \n- addresstown\n- \n- addresszip\n- \n- bloodtype\n- \n- comments\n- \n- medicaldiag\n- \n- namelast\n- Doe\n- namem\n- \n- oculardiag\n- \n- race\n- \n- telenumber\n- \n	---\n- addresscountry\n- ''\n- addressstate\n- ''\n- addressstreet\n- ''\n- addresstown\n- ''\n- addresszip\n- ''\n- bloodtype\n- ''\n- comments\n- ''\n- medicaldiag\n- ''\n- namelast\n- Doe1\n- namem\n- ''\n- oculardiag\n- ''\n- race\n- ''\n- telenumber\n- ''\n	2012-09-07 10:13:27.271561	2012-09-07 10:13:27.271561
3	39	13	---\n- namelast\n- Doe1\n	---\n- namelast\n- Doe\n	2012-09-07 10:13:35.636372	2012-09-07 10:13:35.636372
4	56	65	---\n- namefirst\n- Jane\n- namelast\n- Doe\n- sex\n- F\n	---\n- namefirst\n- James\n- namelast\n- Kirk\n- sex\n- M\n	2012-10-01 18:41:18.604637	2012-10-01 18:41:18.604637
5	69	67	---\n- comments\n- \n- medicaldiag\n- \n	---\n- comments\n- ''\n- medicaldiag\n- Glaucoma\n	2012-10-07 14:28:09.401891	2012-10-07 14:28:09.401891
6	71	68	---\n- comments\n- \n- medicaldiag\n- \n	---\n- comments\n- ''\n- medicaldiag\n- ''\n	2012-10-08 02:33:06.128825	2012-10-08 02:33:06.128825
7	79	73	---\n- comments\n- \n- medicaldiag\n- \n	---\n- comments\n- ''\n- medicaldiag\n- medical\n	2012-10-10 11:47:58.730552	2012-10-10 11:47:58.730552
8	82	75	---\n- comments\n- \n- medicaldiag\n- \n	---\n- comments\n- ''\n- medicaldiag\n- medical\n	2012-10-10 13:05:11.26669	2012-10-10 13:05:11.26669
9	125	83	---\n- comments\n- \n- medicaldiag\n- \n	---\n- comments\n- ''\n- medicaldiag\n- ''\n	2012-10-11 14:22:41.448578	2012-10-11 14:22:41.448578
10	131	85	---\n- comments\n- \n- medicaldiag\n- \n- namelast\n- Doe\n	---\n- comments\n- ''\n- medicaldiag\n- ''\n- namelast\n- Doe1\n	2012-10-12 03:40:54.067539	2012-10-12 03:40:54.067539
11	260	3812	--- []\n	--- []\n	2012-10-25 11:06:40.243003	2012-10-25 11:06:40.243003
12	277	3	--- []\n	--- []\n	2012-10-26 11:31:12.953585	2012-10-26 11:31:12.953585
13	281	3	--- []\n	--- []\n	2012-10-29 05:42:54.798857	2012-10-29 05:42:54.798857
14	283	6	---\n- medicaldiag\n- ''\n	---\n- medicaldiag\n- Medical\n	2012-10-29 05:45:43.250832	2012-10-29 05:45:43.250832
15	284	6	--- []\n	--- []\n	2012-10-29 05:46:11.860794	2012-10-29 05:46:11.860794
16	285	3	---\n- medicaldiag\n- ''\n	---\n- medicaldiag\n- Medical\n	2012-10-29 05:46:28.50766	2012-10-29 05:46:28.50766
17	286	5	---\n- addresscountry\n- \n- addressstate\n- \n- addressstreet\n- \n- addresstown\n- \n- addresszip\n- \n- comments\n- \n- medicaldiag\n- \n- telenumber\n- \n	---\n- addresscountry\n- ''\n- addressstate\n- ''\n- addressstreet\n- ''\n- addresstown\n- ''\n- addresszip\n- ''\n- comments\n- ''\n- medicaldiag\n- Medical\n- telenumber\n- ''\n	2012-10-29 05:49:57.078133	2012-10-29 05:49:57.078133
18	287	5	--- []\n	--- []\n	2012-10-29 06:13:01.125816	2012-10-29 06:13:01.125816
19	288	5	---\n- sex\n- F\n	---\n- sex\n- Male\n	2012-10-29 06:21:41.290894	2012-10-29 06:21:41.290894
20	289	3	---\n- sex\n- \n	---\n- sex\n- Female\n	2012-10-29 06:22:01.392061	2012-10-29 06:22:01.392061
21	290	3	---\n- sex\n- Female\n	---\n- sex\n- Male\n	2012-10-29 06:22:38.62303	2012-10-29 06:22:38.62303
22	310	14	---\n- birthdate\n- \n	---\n- birthdate\n- 2012-10-25 00:00:00.000000000 Z\n	2012-10-31 10:13:41.976285	2012-10-31 10:13:41.976285
\.


--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY audits (id, record_id, record_type, date, ip, action, created_at, updated_at) FROM stdin;
1	2	patienttbs	2012-08-24 13:31:45.42815	122.176.115.234	.Zip Uplaod	2012-08-24 13:31:45.437822	2012-08-24 13:31:45.437822
2	3	slitlamptbs	2012-08-24 13:31:45.466812	122.176.115.234	.Zip Uplaod	2012-08-24 13:31:45.467504	2012-08-24 13:31:45.467504
3	2	patienttbs	2012-08-27 12:37:32.766449	122.176.115.234	.Zip Uplaod	2012-08-27 12:37:32.776359	2012-08-27 12:37:32.776359
4	3	slitlamptbs	2012-08-27 12:37:32.782124	122.176.115.234	.Zip Uplaod	2012-08-27 12:37:32.782693	2012-08-27 12:37:32.782693
5	1	patienttb	2012-08-28 10:20:45.849281	122.176.115.234	Del	2012-08-28 10:20:45.858236	2012-08-28 10:20:45.858236
6	2	patienttb	2012-08-28 10:20:51.789882	122.176.115.234	Del	2012-08-28 10:20:51.798567	2012-08-28 10:20:51.798567
7	3	patienttb	2012-08-28 10:20:56.834197	122.176.115.234	Del	2012-08-28 10:20:56.842828	2012-08-28 10:20:56.842828
8	4	patienttb	2012-08-28 10:21:01.30968	122.176.115.234	Del	2012-08-28 10:21:01.35061	2012-08-28 10:21:01.35061
9	2	patienttbs	2012-08-28 10:21:35.937655	122.176.115.234	.Zip Uplaod	2012-08-28 10:21:35.94771	2012-08-28 10:21:35.94771
10	3	slitlamptbs	2012-08-28 10:21:35.952955	122.176.115.234	.Zip Uplaod	2012-08-28 10:21:35.953577	2012-08-28 10:21:35.953577
11	2	patienttbs	2012-08-29 18:06:02.359751	117.206.197.251	.Zip Uplaod	2012-08-29 18:06:02.402319	2012-08-29 18:06:02.402319
12	3	slitlamptbs	2012-08-29 18:06:02.408769	117.206.197.251	.Zip Uplaod	2012-08-29 18:06:02.409337	2012-08-29 18:06:02.409337
13	2	patienttbs	2012-08-31 16:02:05.558092	72.19.81.238	.Zip Uplaod	2012-08-31 16:02:05.567855	2012-08-31 16:02:05.567855
14	3	slitlamptbs	2012-08-31 16:02:05.647835	72.19.81.238	.Zip Uplaod	2012-08-31 16:02:05.648512	2012-08-31 16:02:05.648512
15	2	patienttbs	2012-08-31 16:04:33.73418	72.19.81.238	.Zip Uplaod	2012-08-31 16:04:33.744109	2012-08-31 16:04:33.744109
16	3	slitlamptbs	2012-08-31 16:04:33.749458	72.19.81.238	.Zip Uplaod	2012-08-31 16:04:33.750073	2012-08-31 16:04:33.750073
17	2	patienttbs	2012-09-03 08:16:25.242181	122.176.115.234	.Zip Uplaod	2012-09-03 08:16:25.251756	2012-09-03 08:16:25.251756
18	3	slitlamptbs	2012-09-03 08:16:25.257521	122.176.115.234	.Zip Uplaod	2012-09-03 08:16:25.25807	2012-09-03 08:16:25.25807
19	2	patienttbs	2012-09-03 08:22:19.937849	122.176.115.234	.Zip Uplaod	2012-09-03 08:22:19.947748	2012-09-03 08:22:19.947748
20	3	slitlamptbs	2012-09-03 08:22:19.952927	122.176.115.234	.Zip Uplaod	2012-09-03 08:22:19.953554	2012-09-03 08:22:19.953554
21	2	patienttbs	2012-09-03 10:03:36.427692	122.176.115.234	.Zip Uplaod	2012-09-03 10:03:36.438094	2012-09-03 10:03:36.438094
22	3	slitlamptbs	2012-09-03 10:03:36.443838	122.176.115.234	.Zip Uplaod	2012-09-03 10:03:36.444481	2012-09-03 10:03:36.444481
23		patienttbs	2012-09-03 10:58:08.255016	122.176.115.234	.Zip Uplaod	2012-09-03 10:58:08.264779	2012-09-03 10:58:08.264779
24		slitlamptbs	2012-09-03 10:58:08.269731	122.176.115.234	.Zip Uplaod	2012-09-03 10:58:08.270276	2012-09-03 10:58:08.270276
25	2	patienttbs	2012-09-03 11:07:13.255496	122.176.115.234	.Zip Uplaod	2012-09-03 11:07:13.265273	2012-09-03 11:07:13.265273
26	3	slitlamptbs	2012-09-03 11:07:13.270199	122.176.115.234	.Zip Uplaod	2012-09-03 11:07:13.27075	2012-09-03 11:07:13.27075
27	2	patienttbs	2012-09-03 11:12:38.036674	122.176.115.234	.Zip Uplaod	2012-09-03 11:12:38.046487	2012-09-03 11:12:38.046487
28	3	slitlamptbs	2012-09-03 11:12:38.051567	122.176.115.234	.Zip Uplaod	2012-09-03 11:12:38.052131	2012-09-03 11:12:38.052131
29	2	patienttbs	2012-09-03 11:31:45.694832	122.176.115.234	.Zip Uplaod	2012-09-03 11:31:45.735453	2012-09-03 11:31:45.735453
30	3	slitlamptbs	2012-09-03 11:31:45.741655	122.176.115.234	.Zip Uplaod	2012-09-03 11:31:45.742215	2012-09-03 11:31:45.742215
31	10	patienttb	2012-09-05 10:28:12.577371	122.176.115.234	Mod	2012-09-05 10:28:12.585874	2012-09-05 10:28:12.585874
32	1	patienttb	2012-09-05 11:15:59.841657	122.176.115.234	Del	2012-09-05 11:15:59.85002	2012-09-05 11:15:59.85002
33	11	patienttb	2012-09-05 11:16:09.915223	122.176.115.234	New	2012-09-05 11:16:09.923372	2012-09-05 11:16:09.923372
34	11	patienttb	2012-09-05 11:16:36.174675	122.176.115.234	Del	2012-09-05 11:16:36.182758	2012-09-05 11:16:36.182758
35	2	patienttb	2012-09-05 15:37:59.315698	122.176.115.234	Del	2012-09-05 15:37:59.323987	2012-09-05 15:37:59.323987
36	2	patienttbs	2012-09-06 06:26:08.857092	122.176.115.234	.Zip Uplaod	2012-09-06 06:26:08.867412	2012-09-06 06:26:08.867412
37	3	slitlamptbs	2012-09-06 06:26:08.87295	122.176.115.234	.Zip Uplaod	2012-09-06 06:26:08.873522	2012-09-06 06:26:08.873522
38	13	patienttb	2012-09-07 10:13:27.216007	122.176.115.234	Mod	2012-09-07 10:13:27.224678	2012-09-07 10:13:27.224678
39	13	patienttb	2012-09-07 10:13:35.602132	122.176.115.234	Mod	2012-09-07 10:13:35.610505	2012-09-07 10:13:35.610505
40	13	patienttb	2012-09-26 10:07:07.615861	122.176.115.234	Del	2012-09-26 10:07:07.624515	2012-09-26 10:07:07.624515
41	2	patienttbs	2012-09-26 11:56:40.691998	122.176.115.234	.Zip Uplaod	2012-09-26 11:56:40.701934	2012-09-26 11:56:40.701934
42	3	slitlamptbs	2012-09-26 11:56:40.758788	122.176.115.234	.Zip Uplaod	2012-09-26 11:56:40.759645	2012-09-26 11:56:40.759645
43	20	patienttb	2012-09-26 11:57:50.888206	122.176.115.234	New	2012-09-26 11:57:50.897076	2012-09-26 11:57:50.897076
44	54	patienttb	2012-09-26 12:15:09.877755	122.176.115.234	New	2012-09-26 12:15:09.932375	2012-09-26 12:15:09.932375
45	2	patienttbs	2012-09-26 12:43:58.986141	122.176.115.234	.Zip Uplaod	2012-09-26 12:43:58.996492	2012-09-26 12:43:58.996492
46	3	slitlamptbs	2012-09-26 12:43:59.015728	122.176.115.234	.Zip Uplaod	2012-09-26 12:43:59.016464	2012-09-26 12:43:59.016464
47	2	patienttbs	2012-09-26 13:32:20.47781	122.176.115.234	.Zip Uplaod	2012-09-26 13:32:20.488119	2012-09-26 13:32:20.488119
48	3	slitlamptbs	2012-09-26 13:32:20.529307	122.176.115.234	.Zip Uplaod	2012-09-26 13:32:20.530082	2012-09-26 13:32:20.530082
49	59	patienttb	2012-09-28 08:24:28.807932	122.176.115.234	New	2012-09-28 08:24:28.817147	2012-09-28 08:24:28.817147
50	60	patienttb	2012-09-30 18:35:49.635134	121.245.43.8	New	2012-09-30 18:35:49.645016	2012-09-30 18:35:49.645016
51	2	patienttbs	2012-09-30 18:41:19.566841	121.245.43.8	.Zip Uplaod	2012-09-30 18:41:19.577123	2012-09-30 18:41:19.577123
52	3	slitlamptbs	2012-09-30 18:41:19.582498	121.245.43.8	.Zip Uplaod	2012-09-30 18:41:19.583165	2012-09-30 18:41:19.583165
53	2	patienttbs	2012-10-01 18:39:39.049397	146.115.68.9	.Zip Uplaod	2012-10-01 18:39:39.060101	2012-10-01 18:39:39.060101
54	3	slitlamptbs	2012-10-01 18:39:39.065614	146.115.68.9	.Zip Uplaod	2012-10-01 18:39:39.066261	2012-10-01 18:39:39.066261
55	65	patienttb	2012-10-01 18:40:49.420819	146.115.68.9	New	2012-10-01 18:40:49.429874	2012-10-01 18:40:49.429874
56	65	patienttb	2012-10-01 18:41:18.549226	146.115.68.9	Mod	2012-10-01 18:41:18.55851	2012-10-01 18:41:18.55851
57	75	slitlamptbs	2012-10-05 13:33:55.448197	122.176.115.234	Del	2012-10-05 13:33:55.458258	2012-10-05 13:33:55.458258
58	22	slitlamptbs	2012-10-05 13:34:01.940587	122.176.115.234	Del	2012-10-05 13:34:01.949705	2012-10-05 13:34:01.949705
59	63	slitlamptbs	2012-10-05 13:34:08.216386	122.176.115.234	Del	2012-10-05 13:34:08.225569	2012-10-05 13:34:08.225569
60	64	slitlamptbs	2012-10-05 13:34:13.265184	122.176.115.234	Del	2012-10-05 13:34:13.274045	2012-10-05 13:34:13.274045
61	65	slitlamptbs	2012-10-05 13:34:17.437114	122.176.115.234	Del	2012-10-05 13:34:17.445984	2012-10-05 13:34:17.445984
62	66	slitlamptbs	2012-10-05 13:34:22.250564	122.176.115.234	Del	2012-10-05 13:34:22.259646	2012-10-05 13:34:22.259646
63	74	slitlamptbs	2012-10-05 13:34:31.434564	122.176.115.234	Del	2012-10-05 13:34:31.48971	2012-10-05 13:34:31.48971
64	66	patienttb	2012-10-05 13:43:35.039696	122.176.115.234	New	2012-10-05 13:43:35.049208	2012-10-05 13:43:35.049208
65	2	patienttbs	2012-10-05 13:51:03.106675	122.176.115.234	.Zip Uplaod	2012-10-05 13:51:03.117143	2012-10-05 13:51:03.117143
66	3	slitlamptbs	2012-10-05 13:51:03.122384	122.176.115.234	.Zip Uplaod	2012-10-05 13:51:03.122967	2012-10-05 13:51:03.122967
67	2	patienttbs	2012-10-05 13:56:50.902825	122.176.115.234	.Zip Uplaod	2012-10-05 13:56:50.91341	2012-10-05 13:56:50.91341
68	3	slitlamptbs	2012-10-05 13:56:50.918951	122.176.115.234	.Zip Uplaod	2012-10-05 13:56:50.919586	2012-10-05 13:56:50.919586
69	67	patienttb	2012-10-07 14:28:09.303516	146.115.68.9	Mod	2012-10-07 14:28:09.359284	2012-10-07 14:28:09.359284
70	71	patienttb	2012-10-07 14:28:58.61077	146.115.68.9	New	2012-10-07 14:28:58.61938	2012-10-07 14:28:58.61938
71	68	patienttb	2012-10-08 02:33:06.044567	146.115.68.9	Mod	2012-10-08 02:33:06.101251	2012-10-08 02:33:06.101251
72	2	patienttbs	2012-10-08 12:24:27.154929	146.115.68.9	.Zip Uplaod	2012-10-08 12:24:27.165481	2012-10-08 12:24:27.165481
73	3	slitlamptbs	2012-10-08 12:24:27.171074	146.115.68.9	.Zip Uplaod	2012-10-08 12:24:27.171699	2012-10-08 12:24:27.171699
74	69	patienttb	2012-10-08 12:24:54.000533	146.115.68.9	Del	2012-10-08 12:24:54.01062	2012-10-08 12:24:54.01062
75	92	slitlamptbs	2012-10-08 12:25:05.811648	146.115.68.9	Del	2012-10-08 12:25:05.821333	2012-10-08 12:25:05.821333
76	70	patienttb	2012-10-08 12:25:24.746828	146.115.68.9	Del	2012-10-08 12:25:24.75572	2012-10-08 12:25:24.75572
77	93	slitlamptbs	2012-10-08 12:25:34.355678	146.115.68.9	Del	2012-10-08 12:25:34.364454	2012-10-08 12:25:34.364454
78	94	slitlamptbs	2012-10-08 12:25:42.513767	146.115.68.9	Del	2012-10-08 12:25:42.522539	2012-10-08 12:25:42.522539
79	73	patienttb	2012-10-10 11:47:58.623423	122.176.115.234	Mod	2012-10-10 11:47:58.673037	2012-10-10 11:47:58.673037
80	2	patienttbs	2012-10-10 13:01:15.963641	122.176.115.234	.Zip Uplaod	2012-10-10 13:01:15.97394	2012-10-10 13:01:15.97394
81	3	slitlamptbs	2012-10-10 13:01:15.979787	122.176.115.234	.Zip Uplaod	2012-10-10 13:01:15.980356	2012-10-10 13:01:15.980356
82	75	patienttb	2012-10-10 13:05:11.166629	122.176.115.234	Mod	2012-10-10 13:05:11.175306	2012-10-10 13:05:11.175306
83	84	slitlamptbs	2012-10-10 15:19:16.91894	122.176.115.234	Del	2012-10-10 15:19:16.928146	2012-10-10 15:19:16.928146
84	89	slitlamptbs	2012-10-10 15:19:23.457226	122.176.115.234	Del	2012-10-10 15:19:23.465702	2012-10-10 15:19:23.465702
85	90	slitlamptbs	2012-10-10 15:19:29.438114	122.176.115.234	Del	2012-10-10 15:19:29.446936	2012-10-10 15:19:29.446936
116	2	patienttbs	2012-10-11 05:45:48.960175	122.176.115.234	.Zip Uplaod	2012-10-11 05:45:48.970214	2012-10-11 05:45:48.970214
117	3	slitlamptbs	2012-10-11 05:45:48.980306	122.176.115.234	.Zip Uplaod	2012-10-11 05:45:48.98088	2012-10-11 05:45:48.98088
118	2	patienttbs	2012-10-11 08:11:15.712261	127.0.0.1	.Zip Uplaod	2012-10-11 08:11:15.733052	2012-10-11 08:11:15.733052
119	3	slitlamptbs	2012-10-11 08:11:15.833996	127.0.0.1	.Zip Uplaod	2012-10-11 08:11:15.836817	2012-10-11 08:11:15.836817
120	107	slitlamptbs	2012-10-11 12:03:51.306085	127.0.0.1	Del	2012-10-11 12:03:51.319228	2012-10-11 12:03:51.319228
121	2	patienttbs	2012-10-11 14:11:01.111063	127.0.0.1	.Zip Uplaod	2012-10-11 14:11:01.124444	2012-10-11 14:11:01.124444
122	3	slitlamptbs	2012-10-11 14:11:01.244754	127.0.0.1	.Zip Uplaod	2012-10-11 14:11:01.246096	2012-10-11 14:11:01.246096
123	2	patienttbs	2012-10-11 14:11:22.378101	127.0.0.1	.Zip Uplaod	2012-10-11 14:11:22.391189	2012-10-11 14:11:22.391189
124	3	slitlamptbs	2012-10-11 14:11:22.471199	127.0.0.1	.Zip Uplaod	2012-10-11 14:11:22.472357	2012-10-11 14:11:22.472357
125	83	patienttb	2012-10-11 14:22:41.388035	127.0.0.1	Mod	2012-10-11 14:22:41.400051	2012-10-11 14:22:41.400051
126		patienttbs	2012-10-11 17:14:58.501989	127.0.0.1	.Zip Uplaod	2012-10-11 17:14:58.514062	2012-10-11 17:14:58.514062
127		slitlamptbs	2012-10-11 17:14:58.681664	127.0.0.1	.Zip Uplaod	2012-10-11 17:14:58.683912	2012-10-11 17:14:58.683912
128	78	patienttb	2012-10-11 17:15:42.711398	127.0.0.1	Del	2012-10-11 17:15:42.721802	2012-10-11 17:15:42.721802
129	2	patienttbs	2012-10-11 17:17:05.945145	127.0.0.1	.Zip Uplaod	2012-10-11 17:17:05.957829	2012-10-11 17:17:05.957829
130	3	slitlamptbs	2012-10-11 17:17:05.97558	127.0.0.1	.Zip Uplaod	2012-10-11 17:17:05.978236	2012-10-11 17:17:05.978236
131	85	patienttb	2012-10-12 03:40:53.962329	127.0.0.1	Mod	2012-10-12 03:40:53.975226	2012-10-12 03:40:53.975226
132	86	patienttb	2012-10-12 10:22:47.87449	127.0.0.1	New	2012-10-12 10:22:47.900122	2012-10-12 10:22:47.900122
133	83	patienttb	2012-10-12 10:27:16.377515	127.0.0.1	Del	2012-10-12 10:27:16.389754	2012-10-12 10:27:16.389754
134	84	patienttb	2012-10-12 10:29:25.146879	127.0.0.1	Del	2012-10-12 10:29:25.160706	2012-10-12 10:29:25.160706
135	2	patienttbs	2012-10-15 11:15:44.754137	127.0.0.1	.Zip Uplaod	2012-10-15 11:15:44.815321	2012-10-15 11:15:44.815321
136	3	slitlamptbs	2012-10-15 11:15:44.902708	127.0.0.1	.Zip Uplaod	2012-10-15 11:15:44.906209	2012-10-15 11:15:44.906209
137	2	patienttbs	2012-10-15 11:18:25.816689	127.0.0.1	.Zip Uplaod	2012-10-15 11:18:25.829773	2012-10-15 11:18:25.829773
138	3	slitlamptbs	2012-10-15 11:18:25.850524	127.0.0.1	.Zip Uplaod	2012-10-15 11:18:25.853097	2012-10-15 11:18:25.853097
139	2	patienttbs	2012-10-15 11:23:39.995849	127.0.0.1	.Zip Uplaod	2012-10-15 11:23:40.009484	2012-10-15 11:23:40.009484
140	3	slitlamptbs	2012-10-15 11:23:40.093134	127.0.0.1	.Zip Uplaod	2012-10-15 11:23:40.095864	2012-10-15 11:23:40.095864
141	2	patienttbs	2012-10-15 11:26:29.136701	127.0.0.1	.Zip Uplaod	2012-10-15 11:26:29.14887	2012-10-15 11:26:29.14887
142	3	slitlamptbs	2012-10-15 11:26:29.174908	127.0.0.1	.Zip Uplaod	2012-10-15 11:26:29.177617	2012-10-15 11:26:29.177617
143	2	patienttbs	2012-10-15 15:02:32.276165	127.0.0.1	.Zip Uplaod	2012-10-15 15:02:32.288434	2012-10-15 15:02:32.288434
144	3	slitlamptbs	2012-10-15 15:02:32.517452	127.0.0.1	.Zip Uplaod	2012-10-15 15:02:32.519689	2012-10-15 15:02:32.519689
145	112	slitlamptbs	2012-10-15 20:18:57.043348	127.0.0.1	Del	2012-10-15 20:18:57.067966	2012-10-15 20:18:57.067966
146	114	slitlamptbs	2012-10-15 20:19:02.459327	127.0.0.1	Del	2012-10-15 20:19:02.474042	2012-10-15 20:19:02.474042
147	115	slitlamptbs	2012-10-15 20:19:06.792011	127.0.0.1	Del	2012-10-15 20:19:06.801766	2012-10-15 20:19:06.801766
148	135	slitlamptbs	2012-10-15 20:19:11.38831	127.0.0.1	Del	2012-10-15 20:19:11.3992	2012-10-15 20:19:11.3992
149	125	slitlamptbs	2012-10-15 20:19:24.99546	127.0.0.1	Del	2012-10-15 20:19:25.007964	2012-10-15 20:19:25.007964
150	126	slitlamptbs	2012-10-15 20:19:29.196896	127.0.0.1	Del	2012-10-15 20:19:29.208309	2012-10-15 20:19:29.208309
151	119	slitlamptbs	2012-10-15 20:19:55.460882	127.0.0.1	Del	2012-10-15 20:19:55.476206	2012-10-15 20:19:55.476206
152	124	slitlamptbs	2012-10-15 20:20:00.076033	127.0.0.1	Del	2012-10-15 20:20:00.087503	2012-10-15 20:20:00.087503
153	137	slitlamptbs	2012-10-15 20:20:04.197187	127.0.0.1	Del	2012-10-15 20:20:04.211092	2012-10-15 20:20:04.211092
154	138	slitlamptbs	2012-10-15 20:20:12.739999	127.0.0.1	Del	2012-10-15 20:20:12.755543	2012-10-15 20:20:12.755543
155	108	slitlamptbs	2012-10-15 20:20:18.054743	127.0.0.1	Del	2012-10-15 20:20:18.066834	2012-10-15 20:20:18.066834
156	127	slitlamptbs	2012-10-15 20:20:22.214638	127.0.0.1	Del	2012-10-15 20:20:22.231678	2012-10-15 20:20:22.231678
157	116	slitlamptbs	2012-10-15 20:20:26.228217	127.0.0.1	Del	2012-10-15 20:20:26.238839	2012-10-15 20:20:26.238839
158	109	slitlamptbs	2012-10-15 20:20:29.845691	127.0.0.1	Del	2012-10-15 20:20:29.858122	2012-10-15 20:20:29.858122
159	136	slitlamptbs	2012-10-15 20:20:34.1651	127.0.0.1	Del	2012-10-15 20:20:34.177791	2012-10-15 20:20:34.177791
160	2	patienttbs	2012-10-16 06:05:02.739926	127.0.0.1	.Zip Uplaod	2012-10-16 06:05:02.765097	2012-10-16 06:05:02.765097
161	3	slitlamptbs	2012-10-16 06:05:02.989965	127.0.0.1	.Zip Uplaod	2012-10-16 06:05:02.991836	2012-10-16 06:05:02.991836
162	2	patienttbs	2012-10-16 06:10:49.869587	127.0.0.1	.Zip Uplaod	2012-10-16 06:10:49.88172	2012-10-16 06:10:49.88172
163	3	slitlamptbs	2012-10-16 06:10:49.896479	127.0.0.1	.Zip Uplaod	2012-10-16 06:10:49.897307	2012-10-16 06:10:49.897307
164	2	patienttbs	2012-10-16 08:01:43.321374	127.0.0.1	.Zip Uplaod	2012-10-16 08:01:43.33351	2012-10-16 08:01:43.33351
165	3	slitlamptbs	2012-10-16 08:01:43.371268	127.0.0.1	.Zip Uplaod	2012-10-16 08:01:43.373634	2012-10-16 08:01:43.373634
166	2	patienttbs	2012-10-16 08:03:35.026315	127.0.0.1	.Zip Uplaod	2012-10-16 08:03:35.040014	2012-10-16 08:03:35.040014
167	3	slitlamptbs	2012-10-16 08:03:35.05524	127.0.0.1	.Zip Uplaod	2012-10-16 08:03:35.056939	2012-10-16 08:03:35.056939
168	2	patienttbs	2012-10-16 08:06:03.352785	127.0.0.1	.Zip Uplaod	2012-10-16 08:06:03.366226	2012-10-16 08:06:03.366226
169	3	slitlamptbs	2012-10-16 08:06:03.381921	127.0.0.1	.Zip Uplaod	2012-10-16 08:06:03.383325	2012-10-16 08:06:03.383325
170	2	patienttbs	2012-10-16 08:06:56.783542	127.0.0.1	.Zip Uplaod	2012-10-16 08:06:56.796557	2012-10-16 08:06:56.796557
171	3	slitlamptbs	2012-10-16 08:06:56.825348	127.0.0.1	.Zip Uplaod	2012-10-16 08:06:56.828052	2012-10-16 08:06:56.828052
172	2	patienttbs	2012-10-16 08:08:43.721014	127.0.0.1	.Zip Uplaod	2012-10-16 08:08:43.732201	2012-10-16 08:08:43.732201
173	3	slitlamptbs	2012-10-16 08:08:43.833581	127.0.0.1	.Zip Uplaod	2012-10-16 08:08:43.835939	2012-10-16 08:08:43.835939
174	2	patienttbs	2012-10-16 08:11:04.361892	127.0.0.1	.Zip Uplaod	2012-10-16 08:11:04.373672	2012-10-16 08:11:04.373672
175	3	slitlamptbs	2012-10-16 08:11:04.394131	127.0.0.1	.Zip Uplaod	2012-10-16 08:11:04.396744	2012-10-16 08:11:04.396744
176	2	patienttbs	2012-10-16 08:20:36.725388	127.0.0.1	.Zip Uplaod	2012-10-16 08:20:36.737431	2012-10-16 08:20:36.737431
177	3	slitlamptbs	2012-10-16 08:20:36.75776	127.0.0.1	.Zip Uplaod	2012-10-16 08:20:36.760119	2012-10-16 08:20:36.760119
178	104	patienttb	2012-10-16 11:44:49.563913	127.0.0.1	Del	2012-10-16 11:44:49.579435	2012-10-16 11:44:49.579435
179	111	patienttb	2012-10-16 11:45:04.264497	127.0.0.1	Del	2012-10-16 11:45:04.275196	2012-10-16 11:45:04.275196
180	114	patienttb	2012-10-16 11:45:11.245582	127.0.0.1	Del	2012-10-16 11:45:11.256184	2012-10-16 11:45:11.256184
181	112	patienttb	2012-10-16 11:45:16.900754	127.0.0.1	Del	2012-10-16 11:45:16.912983	2012-10-16 11:45:16.912983
182	102	patienttb	2012-10-16 11:45:21.870224	127.0.0.1	Del	2012-10-16 11:45:21.880051	2012-10-16 11:45:21.880051
183	109	patienttb	2012-10-16 11:45:26.851971	127.0.0.1	Del	2012-10-16 11:45:26.863907	2012-10-16 11:45:26.863907
184	108	patienttb	2012-10-16 11:45:33.818359	127.0.0.1	Del	2012-10-16 11:45:33.830862	2012-10-16 11:45:33.830862
185	113	patienttb	2012-10-16 11:45:39.07735	127.0.0.1	Del	2012-10-16 11:45:39.089051	2012-10-16 11:45:39.089051
186	106	patienttb	2012-10-16 11:45:47.600524	127.0.0.1	Del	2012-10-16 11:45:47.621615	2012-10-16 11:45:47.621615
187	110	patienttb	2012-10-16 11:45:54.740264	127.0.0.1	Del	2012-10-16 11:45:54.751562	2012-10-16 11:45:54.751562
188	107	patienttb	2012-10-16 11:46:05.079365	127.0.0.1	Del	2012-10-16 11:46:05.095261	2012-10-16 11:46:05.095261
189	105	patienttb	2012-10-16 11:46:11.609863	127.0.0.1	Del	2012-10-16 11:46:11.622126	2012-10-16 11:46:11.622126
190	103	patienttb	2012-10-16 11:46:17.371014	127.0.0.1	Del	2012-10-16 11:46:17.384313	2012-10-16 11:46:17.384313
191	100	patienttb	2012-10-16 11:46:23.575075	127.0.0.1	Del	2012-10-16 11:46:23.58762	2012-10-16 11:46:23.58762
192	101	patienttb	2012-10-16 11:46:30.33047	127.0.0.1	Del	2012-10-16 11:46:30.386704	2012-10-16 11:46:30.386704
193	99	patienttb	2012-10-16 11:46:36.664158	127.0.0.1	Del	2012-10-16 11:46:36.677045	2012-10-16 11:46:36.677045
194	98	patienttb	2012-10-16 11:46:44.036381	127.0.0.1	Del	2012-10-16 11:46:44.058586	2012-10-16 11:46:44.058586
195	96	patienttb	2012-10-16 11:46:49.399495	127.0.0.1	Del	2012-10-16 11:46:49.424696	2012-10-16 11:46:49.424696
196	94	patienttb	2012-10-16 11:46:54.414486	127.0.0.1	Del	2012-10-16 11:46:54.425971	2012-10-16 11:46:54.425971
197	95	patienttb	2012-10-16 11:46:59.839092	127.0.0.1	Del	2012-10-16 11:46:59.851064	2012-10-16 11:46:59.851064
198	97	patienttb	2012-10-16 11:47:05.347366	127.0.0.1	Del	2012-10-16 11:47:05.360269	2012-10-16 11:47:05.360269
199	93	patienttb	2012-10-16 11:47:10.362851	127.0.0.1	Del	2012-10-16 11:47:10.374514	2012-10-16 11:47:10.374514
200	92	patienttb	2012-10-16 11:47:16.287457	127.0.0.1	Del	2012-10-16 11:47:16.299665	2012-10-16 11:47:16.299665
201	91	patienttb	2012-10-16 11:47:22.000857	127.0.0.1	Del	2012-10-16 11:47:22.056741	2012-10-16 11:47:22.056741
202	86	patienttb	2012-10-16 11:47:29.412119	127.0.0.1	Del	2012-10-16 11:47:29.424447	2012-10-16 11:47:29.424447
203	79	patienttb	2012-10-16 11:47:34.388463	127.0.0.1	Del	2012-10-16 11:47:34.40381	2012-10-16 11:47:34.40381
204	80	patienttb	2012-10-16 11:47:39.621147	127.0.0.1	Del	2012-10-16 11:47:39.641638	2012-10-16 11:47:39.641638
205	81	patienttb	2012-10-16 11:47:44.565227	127.0.0.1	Del	2012-10-16 11:47:44.619678	2012-10-16 11:47:44.619678
206	89	patienttb	2012-10-16 11:47:53.647945	127.0.0.1	Del	2012-10-16 11:47:53.662159	2012-10-16 11:47:53.662159
207	90	patienttb	2012-10-16 11:47:59.001638	127.0.0.1	Del	2012-10-16 11:47:59.013516	2012-10-16 11:47:59.013516
208	87	patienttb	2012-10-16 11:48:04.351366	127.0.0.1	Del	2012-10-16 11:48:04.408281	2012-10-16 11:48:04.408281
209	85	patienttb	2012-10-16 11:48:10.232401	127.0.0.1	Del	2012-10-16 11:48:10.245098	2012-10-16 11:48:10.245098
210	82	patienttb	2012-10-16 11:48:15.163006	127.0.0.1	Del	2012-10-16 11:48:15.176994	2012-10-16 11:48:15.176994
211	88	patienttb	2012-10-16 11:48:20.52973	127.0.0.1	Del	2012-10-16 11:48:20.541166	2012-10-16 11:48:20.541166
212	2	patienttbs	2012-10-16 11:53:21.46256	127.0.0.1	.Zip Uplaod	2012-10-16 11:53:21.474579	2012-10-16 11:53:21.474579
213	3	slitlamptbs	2012-10-16 11:53:21.503459	127.0.0.1	.Zip Uplaod	2012-10-16 11:53:21.505855	2012-10-16 11:53:21.505855
214	2	patienttbs	2012-10-16 12:48:18.666566	127.0.0.1	.Zip Uplaod	2012-10-16 12:48:18.678852	2012-10-16 12:48:18.678852
215	3	slitlamptbs	2012-10-16 12:48:18.704781	127.0.0.1	.Zip Uplaod	2012-10-16 12:48:18.707776	2012-10-16 12:48:18.707776
216	118	patienttb	2012-10-16 12:48:29.857619	127.0.0.1	Del	2012-10-16 12:48:29.871172	2012-10-16 12:48:29.871172
217	117	patienttb	2012-10-16 12:48:34.747529	127.0.0.1	Del	2012-10-16 12:48:34.761928	2012-10-16 12:48:34.761928
218	2	patienttbs	2012-10-16 12:49:23.616791	127.0.0.1	.Zip Uplaod	2012-10-16 12:49:23.628754	2012-10-16 12:49:23.628754
219	3	slitlamptbs	2012-10-16 12:49:23.745302	127.0.0.1	.Zip Uplaod	2012-10-16 12:49:23.746313	2012-10-16 12:49:23.746313
220	120	patienttb	2012-10-16 12:49:35.078525	127.0.0.1	Del	2012-10-16 12:49:35.091358	2012-10-16 12:49:35.091358
221	119	patienttb	2012-10-16 12:49:39.523243	127.0.0.1	Del	2012-10-16 12:49:39.535451	2012-10-16 12:49:39.535451
222	919	patienttbs	2012-10-16 14:15:25.709389	127.0.0.1	.Zip Uplaod	2012-10-16 14:15:25.729571	2012-10-16 14:15:25.729571
223	14026	slitlamptbs	2012-10-16 14:15:26.057673	127.0.0.1	.Zip Uplaod	2012-10-16 14:15:26.060031	2012-10-16 14:15:26.060031
224	2	patienttbs	2012-10-16 15:45:51.466842	127.0.0.1	.Zip Uplaod	2012-10-16 15:45:51.478534	2012-10-16 15:45:51.478534
225	3	slitlamptbs	2012-10-16 15:45:51.510971	127.0.0.1	.Zip Uplaod	2012-10-16 15:45:51.512102	2012-10-16 15:45:51.512102
226	919	patienttbs	2012-10-16 15:53:23.597242	127.0.0.1	.Zip Uplaod	2012-10-16 15:53:23.62196	2012-10-16 15:53:23.62196
227	14026	slitlamptbs	2012-10-16 15:53:23.642674	127.0.0.1	.Zip Uplaod	2012-10-16 15:53:23.645791	2012-10-16 15:53:23.645791
228	919	patienttbs	2012-10-16 17:20:19.783663	127.0.0.1	.Zip Uplaod	2012-10-16 17:20:19.842455	2012-10-16 17:20:19.842455
229	14026	slitlamptbs	2012-10-16 17:20:20.099409	127.0.0.1	.Zip Uplaod	2012-10-16 17:20:20.101804	2012-10-16 17:20:20.101804
230	919	patienttbs	2012-10-16 17:42:24.214041	127.0.0.1	.Zip Uplaod	2012-10-16 17:42:24.226179	2012-10-16 17:42:24.226179
231	14026	slitlamptbs	2012-10-16 17:42:24.271556	127.0.0.1	.Zip Uplaod	2012-10-16 17:42:24.273836	2012-10-16 17:42:24.273836
232	42395	slitlamptbs	2012-10-18 08:29:01.663054	127.0.0.1	Del	2012-10-18 08:29:01.71015	2012-10-18 08:29:01.71015
233	2	patienttbs	2012-10-21 18:55:31.630343	127.0.0.1	.Zip Uplaod	2012-10-21 18:55:31.638771	2012-10-21 18:55:31.638771
234	3	slitlamptbs	2012-10-21 18:55:31.981349	127.0.0.1	.Zip Uplaod	2012-10-21 18:55:31.984413	2012-10-21 18:55:31.984413
235	2	patienttbs	2012-10-21 19:02:58.955651	127.0.0.1	.Zip Uplaod	2012-10-21 19:02:58.967705	2012-10-21 19:02:58.967705
236	3	slitlamptbs	2012-10-21 19:02:59.029574	127.0.0.1	.Zip Uplaod	2012-10-21 19:02:59.031874	2012-10-21 19:02:59.031874
237	2	patienttbs	2012-10-22 02:22:26.578975	127.0.0.1	.Zip Uplaod	2012-10-22 02:22:26.593911	2012-10-22 02:22:26.593911
238	3	slitlamptbs	2012-10-22 02:22:26.672005	127.0.0.1	.Zip Uplaod	2012-10-22 02:22:26.674125	2012-10-22 02:22:26.674125
239	56294	slitlamptbs	2012-10-22 02:23:56.618659	127.0.0.1	Del	2012-10-22 02:23:56.630004	2012-10-22 02:23:56.630004
240	2	patienttbs	2012-10-22 05:03:11.769143	127.0.0.1	.Zip Uplaod	2012-10-22 05:03:11.781502	2012-10-22 05:03:11.781502
241	3	slitlamptbs	2012-10-22 05:03:11.839349	127.0.0.1	.Zip Uplaod	2012-10-22 05:03:11.842193	2012-10-22 05:03:11.842193
242	56299	slitlamptbs	2012-10-22 07:56:10.009771	127.0.0.1	Del	2012-10-22 07:56:10.022946	2012-10-22 07:56:10.022946
243	56300	slitlamptbs	2012-10-22 07:56:13.945188	127.0.0.1	Del	2012-10-22 07:56:13.968662	2012-10-22 07:56:13.968662
244	56302	slitlamptbs	2012-10-22 08:24:51.924591	127.0.0.1	Del	2012-10-22 08:24:51.980458	2012-10-22 08:24:51.980458
245	56309	slitlamptbs	2012-10-22 13:42:41.822306	127.0.0.1	Del	2012-10-22 13:42:41.841306	2012-10-22 13:42:41.841306
246	56310	slitlamptbs	2012-10-22 13:42:48.399874	127.0.0.1	Del	2012-10-22 13:42:48.412265	2012-10-22 13:42:48.412265
247	56311	slitlamptbs	2012-10-22 13:42:54.457843	127.0.0.1	Del	2012-10-22 13:42:54.480229	2012-10-22 13:42:54.480229
248	56312	slitlamptbs	2012-10-22 13:42:59.864837	127.0.0.1	Del	2012-10-22 13:42:59.892211	2012-10-22 13:42:59.892211
249	56301	slitlamptbs	2012-10-22 19:25:13.991289	127.0.0.1	Del	2012-10-22 19:25:14.012899	2012-10-22 19:25:14.012899
250	56306	slitlamptbs	2012-10-22 19:25:18.456229	127.0.0.1	Del	2012-10-22 19:25:18.459226	2012-10-22 19:25:18.459226
251	2	patienttbs	2012-10-22 19:38:42.678904	127.0.0.1	.Zip Uplaod	2012-10-22 19:38:42.682705	2012-10-22 19:38:42.682705
252	3	slitlamptbs	2012-10-22 19:38:42.709347	127.0.0.1	.Zip Uplaod	2012-10-22 19:38:42.711766	2012-10-22 19:38:42.711766
253	56317	slitlamptbs	2012-10-22 19:56:02.153613	127.0.0.1	Del	2012-10-22 19:56:02.178741	2012-10-22 19:56:02.178741
254	3809	patienttb	2012-10-23 11:39:41.705246	127.0.0.1	New	2012-10-23 11:39:41.717524	2012-10-23 11:39:41.717524
255	3810	patienttb	2012-10-23 11:43:25.273451	127.0.0.1	New	2012-10-23 11:43:25.283964	2012-10-23 11:43:25.283964
256	3805	patienttb	2012-10-25 10:26:16.248918	127.0.0.1	Del	2012-10-25 10:26:16.260223	2012-10-25 10:26:16.260223
257	3809	patienttb	2012-10-25 10:26:25.782019	127.0.0.1	Del	2012-10-25 10:26:25.794778	2012-10-25 10:26:25.794778
258	3811	patienttb	2012-10-25 10:29:09.853174	127.0.0.1	New	2012-10-25 10:29:09.865102	2012-10-25 10:29:09.865102
259	3812	patienttb	2012-10-25 11:04:43.723403	127.0.0.1	New	2012-10-25 11:04:43.736468	2012-10-25 11:04:43.736468
260	3812	patienttb	2012-10-25 11:06:40.180055	127.0.0.1	Mod	2012-10-25 11:06:40.191175	2012-10-25 11:06:40.191175
261	3812	patienttb	2012-10-25 11:30:47.744764	127.0.0.1	Del	2012-10-25 11:30:47.756235	2012-10-25 11:30:47.756235
262	5	slitlamp	2012-10-25 11:50:23.57082	127.0.0.1	Del	2012-10-25 11:50:23.621382	2012-10-25 11:50:23.621382
263	4	slitlamp	2012-10-25 11:50:26.796837	127.0.0.1	Del	2012-10-25 11:50:26.809672	2012-10-25 11:50:26.809672
264	3	slitlamp	2012-10-25 11:50:30.242487	127.0.0.1	Del	2012-10-25 11:50:30.253298	2012-10-25 11:50:30.253298
265	2	patient	2012-10-25 13:49:42.132232	127.0.0.1	New	2012-10-25 13:49:42.147806	2012-10-25 13:49:42.147806
266	2	patient	2012-10-25 14:08:30.57712	127.0.0.1	Del	2012-10-25 14:08:30.589698	2012-10-25 14:08:30.589698
267	3	patient	2012-10-25 14:27:20.318901	127.0.0.1	New	2012-10-25 14:27:20.330651	2012-10-25 14:27:20.330651
268		patienttbs	2012-10-25 14:47:41.09953	127.0.0.1	.Zip Uplaod	2012-10-25 14:47:41.114968	2012-10-25 14:47:41.114968
269		slitlamptbs	2012-10-25 14:47:41.13672	127.0.0.1	.Zip Uplaod	2012-10-25 14:47:41.13795	2012-10-25 14:47:41.13795
270		patienttbs	2012-10-25 14:48:45.699377	127.0.0.1	.Zip Uplaod	2012-10-25 14:48:45.75347	2012-10-25 14:48:45.75347
271		slitlamptbs	2012-10-25 14:48:45.823996	127.0.0.1	.Zip Uplaod	2012-10-25 14:48:45.825975	2012-10-25 14:48:45.825975
272		patienttbs	2012-10-25 14:49:14.24503	127.0.0.1	.Zip Uplaod	2012-10-25 14:49:14.262664	2012-10-25 14:49:14.262664
273		slitlamptbs	2012-10-25 14:49:14.288898	127.0.0.1	.Zip Uplaod	2012-10-25 14:49:14.290872	2012-10-25 14:49:14.290872
274	2	patienttbs	2012-10-25 14:58:53.211299	127.0.0.1	.Zip Uplaod	2012-10-25 14:58:53.224368	2012-10-25 14:58:53.224368
275	3	slitlamptbs	2012-10-25 14:58:53.305975	127.0.0.1	.Zip Uplaod	2012-10-25 14:58:53.307769	2012-10-25 14:58:53.307769
276	4	patient	2012-10-26 05:05:10.496229	127.0.0.1	Del	2012-10-26 05:05:10.50872	2012-10-26 05:05:10.50872
277	3	patient	2012-10-26 11:31:12.847897	127.0.0.1	Mod	2012-10-26 11:31:12.861124	2012-10-26 11:31:12.861124
278	8	slitlamp	2012-10-27 03:50:20.953316	127.0.0.1	Del	2012-10-27 03:50:20.963395	2012-10-27 03:50:20.963395
279	10	slitlamp	2012-10-27 03:50:25.735629	127.0.0.1	Del	2012-10-27 03:50:25.74844	2012-10-27 03:50:25.74844
280	11	slitlamp	2012-10-27 03:50:30.360269	127.0.0.1	Del	2012-10-27 03:50:30.372534	2012-10-27 03:50:30.372534
281	3	patient	2012-10-29 05:42:54.507242	127.0.0.1	Mod	2012-10-29 05:42:54.533046	2012-10-29 05:42:54.533046
282	6	patient	2012-10-29 05:44:37.604598	127.0.0.1	New	2012-10-29 05:44:37.625373	2012-10-29 05:44:37.625373
283	6	patient	2012-10-29 05:45:43.195178	127.0.0.1	Mod	2012-10-29 05:45:43.207027	2012-10-29 05:45:43.207027
284	6	patient	2012-10-29 05:46:11.738846	127.0.0.1	Mod	2012-10-29 05:46:11.792317	2012-10-29 05:46:11.792317
285	3	patient	2012-10-29 05:46:28.449099	127.0.0.1	Mod	2012-10-29 05:46:28.459664	2012-10-29 05:46:28.459664
286	5	patient	2012-10-29 05:49:56.986097	127.0.0.1	Mod	2012-10-29 05:49:56.998318	2012-10-29 05:49:56.998318
287	5	patient	2012-10-29 06:13:01.039936	127.0.0.1	Mod	2012-10-29 06:13:01.051818	2012-10-29 06:13:01.051818
288	5	patient	2012-10-29 06:21:41.226196	127.0.0.1	Mod	2012-10-29 06:21:41.236842	2012-10-29 06:21:41.236842
289	3	patient	2012-10-29 06:22:01.327151	127.0.0.1	Mod	2012-10-29 06:22:01.33894	2012-10-29 06:22:01.33894
290	3	patient	2012-10-29 06:22:38.502743	127.0.0.1	Mod	2012-10-29 06:22:38.556646	2012-10-29 06:22:38.556646
291	2	patienttbs	2012-10-30 05:18:05.323909	127.0.0.1	.Zip Uplaod	2012-10-30 05:18:05.341186	2012-10-30 05:18:05.341186
292	3	slitlamptbs	2012-10-30 05:18:05.686385	127.0.0.1	.Zip Uplaod	2012-10-30 05:18:05.689034	2012-10-30 05:18:05.689034
293	2	patienttbs	2012-10-30 05:33:18.721849	127.0.0.1	.Zip Uplaod	2012-10-30 05:33:18.736407	2012-10-30 05:33:18.736407
294	3	slitlamptbs	2012-10-30 05:33:18.82403	127.0.0.1	.Zip Uplaod	2012-10-30 05:33:18.826849	2012-10-30 05:33:18.826849
295	2	patienttbs	2012-10-30 05:38:08.278663	127.0.0.1	.Zip Uplaod	2012-10-30 05:38:08.332694	2012-10-30 05:38:08.332694
296	3	slitlamptbs	2012-10-30 05:38:08.411363	127.0.0.1	.Zip Uplaod	2012-10-30 05:38:08.413849	2012-10-30 05:38:08.413849
297	7	patient	2012-10-31 07:09:38.129871	127.0.0.1	Del	2012-10-31 07:09:38.143608	2012-10-31 07:09:38.143608
298	9	patient	2012-10-31 07:09:47.223361	127.0.0.1	Del	2012-10-31 07:09:47.235798	2012-10-31 07:09:47.235798
299	6	patient	2012-10-31 07:09:55.132156	127.0.0.1	Del	2012-10-31 07:09:55.149442	2012-10-31 07:09:55.149442
300	10	patient	2012-10-31 07:10:01.943889	127.0.0.1	Del	2012-10-31 07:10:01.95382	2012-10-31 07:10:01.95382
301	5	patient	2012-10-31 07:10:08.52409	127.0.0.1	Del	2012-10-31 07:10:08.53622	2012-10-31 07:10:08.53622
302	12	patient	2012-10-31 09:43:05.364528	127.0.0.1	Del	2012-10-31 09:43:05.375947	2012-10-31 09:43:05.375947
303	11	patient	2012-10-31 09:43:11.243191	127.0.0.1	Del	2012-10-31 09:43:11.252905	2012-10-31 09:43:11.252905
304	8	patient	2012-10-31 09:43:16.896728	127.0.0.1	Del	2012-10-31 09:43:16.949102	2012-10-31 09:43:16.949102
305	3	patient	2012-10-31 09:43:23.242417	127.0.0.1	Del	2012-10-31 09:43:23.259376	2012-10-31 09:43:23.259376
306	12	slitlamp	2012-10-31 09:44:46.437579	127.0.0.1	Del	2012-10-31 09:44:46.49341	2012-10-31 09:44:46.49341
307	13	patient	2012-10-31 09:51:30.464972	127.0.0.1	New	2012-10-31 09:51:30.47542	2012-10-31 09:51:30.47542
308	13	patient	2012-10-31 09:59:38.483748	127.0.0.1	Del	2012-10-31 09:59:38.495289	2012-10-31 09:59:38.495289
309	14	patient	2012-10-31 10:00:19.418021	127.0.0.1	New	2012-10-31 10:00:19.43165	2012-10-31 10:00:19.43165
310	14	patient	2012-10-31 10:13:41.83096	127.0.0.1	Mod	2012-10-31 10:13:41.8427	2012-10-31 10:13:41.8427
311	14	patient	2012-10-31 10:19:29.549818	127.0.0.1	Del	2012-10-31 10:19:29.561232	2012-10-31 10:19:29.561232
312	34	slitlamp	2012-10-31 10:42:11.239028	127.0.0.1	Del	2012-10-31 10:42:11.251791	2012-10-31 10:42:11.251791
313	2	patients	2012-10-31 10:43:07.756088	127.0.0.1	.Zip Uplaod	2012-10-31 10:43:07.768168	2012-10-31 10:43:07.768168
314	3	slitlamps	2012-10-31 10:43:07.832105	127.0.0.1	.Zip Uplaod	2012-10-31 10:43:07.834663	2012-10-31 10:43:07.834663
\.


--
-- Data for Name: automated_db_backups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY automated_db_backups (id, "time", created_at, updated_at) FROM stdin;
1	every '0 0 1 * *'	2012-09-26 10:45:20.476674	2012-10-04 05:40:21.416989
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY devices (id, device_name, created_at, updated_at) FROM stdin;
11	Slit Lamp	2012-10-31 09:49:03.859452	2012-10-31 09:49:03.859452
12	Fundus	2012-10-31 09:52:02.146787	2012-10-31 09:52:02.146787
13	Specular	2012-10-31 09:52:14.990056	2012-10-31 09:52:32.204603
\.


--
-- Data for Name: file_upolads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY file_upolads (id, db_file, created_at, updated_at) FROM stdin;
9	TranscodedWallpaper.jpg	2012-10-19 12:14:24.022438	2012-10-19 12:14:24.022438
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY images (id, patientid, imageid, datetime, od_os, equipinfo, description, celldensity, meancellarea, imagebuffer, title, disease, cddelta, cv, hexagonality, analysed, location, imagefilename, is_delete, db, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mandatory_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mandatory_fields (id, fields, is_mandatory, created_at, updated_at) FROM stdin;
4	ssn	f	2012-08-24 12:03:43.301966	2012-08-27 06:13:52.963601
5	birthdate	f	2012-08-24 12:03:43.303173	2012-08-27 06:13:52.964816
6	namefirst	f	2012-08-24 12:03:43.30437	2012-08-27 06:13:52.966062
7	namem	f	2012-08-24 12:03:43.305549	2012-08-27 06:13:52.967343
8	namelast	f	2012-08-24 12:03:43.306736	2012-08-27 06:13:52.968618
9	race	f	2012-08-24 12:03:43.307868	2012-08-27 06:13:52.969818
10	bloodtype	f	2012-08-24 12:03:43.309048	2012-08-27 06:13:52.971029
11	addressstreet	f	2012-08-24 12:03:43.310205	2012-08-27 06:13:52.972184
12	addresstown	f	2012-08-24 12:03:43.311402	2012-08-27 06:13:52.973463
13	addressstate	f	2012-08-24 12:03:43.312587	2012-08-27 06:13:52.974731
14	addresszip	f	2012-08-24 12:03:43.313765	2012-08-27 06:13:52.976049
15	addresscountry	f	2012-08-24 12:03:43.314987	2012-08-27 06:13:52.977261
16	telenumber	f	2012-08-24 12:03:43.316194	2012-08-27 06:13:52.978419
17	oculardiag	f	2012-08-24 12:03:43.317381	2012-08-27 06:13:52.979912
18	medicaldiag	f	2012-08-24 12:03:43.318599	2012-08-27 06:13:52.981137
19	firstvisitdate	f	2012-08-24 12:03:43.319757	2012-08-27 06:13:52.982444
20	comments	f	2012-08-24 12:03:43.320948	2012-08-27 06:13:52.983666
2	patientid	f	2012-08-24 12:03:42.787893	2012-09-03 09:12:12.809828
3	sex	f	2012-08-24 12:03:43.300536	2012-09-03 09:12:12.812407
\.


--
-- Data for Name: patient_user_defined_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY patient_user_defined_data (id, patient_id, field_name, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: patient_user_defined_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY patient_user_defined_fields (id, field_name, created_at, updated_at) FROM stdin;
1	E-mail	2012-09-08 05:52:51.043099	2012-09-08 05:52:51.043099
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY patients (id, patientid, sex, ssn, birthdate, namefirst, namem, namelast, race, bloodtype, addressstreet, addresstown, addressstate, addresszip, addresscountry, telenumber, oculardiag, medicaldiag, firstvisitdate, comments, is_delete, db, created_at, updated_at) FROM stdin;
15	1	M	___-__-____	2011-01-01 00:00:00	John	\N	Smith	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2012-06-22 00:00:00	\N	f	1	\N	2012-10-31 10:43:08.053249
16	2	F	___-__-____	2011-01-01 00:00:00	Jane	\N	Doe	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2012-08-11 00:00:00	\N	f	1	\N	2012-10-31 10:43:08.082626
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY schema_migrations (version) FROM stdin;
20120818130342
20120820131350
20120821125554
20120827063959
20120829111608
20120907103155
20120921084957
20121019104533
20121023085231
20121023085645
20121023091917
20121023085559
20121023103934
20121023132842
20120830125538
\.


--
-- Data for Name: slitlamps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY slitlamps (id, patient_id, patientid, imageid, datetime, od_os, equipinfo, description, celldensity, meancellarea, imagebuffer, title, disease, cddelta, cv, hexagonality, analysed, location, imagefilename, is_delete, db, created_at, updated_at, pimage_file_name, pimage_content_type, pimage_file_size) FROM stdin;
35	15	1	1	2012-06-22 10:11:00	\N	\N	\N	\N	\N	\N	6/22/2012 10:11:00 A	\N	\N	\N	\N	\N	\N	\N	f	1	\N	2012-10-31 10:43:08.50078	Slitlamp-1-1.jpg	image/jpeg	54008
36	16	2	2	2012-08-11 13:37:41	\N	\N	\N	\N	\N	\N	8/11/2012 1:37:41 PM	\N	\N	\N	\N	\N	\N	\N	f	1	\N	2012-10-31 10:43:08.620573	Slitlamp-2-2.jpg	image/jpeg	62353
37	16	2	3	2012-08-11 13:37:46	\N	\N	\N	\N	\N	\N	8/11/2012 1:37:46 PM	\N	\N	\N	\N	\N	\N	\N	f	1	\N	2012-10-31 10:43:08.764936	Slitlamp-2-3.jpg	image/jpeg	51454
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id, email, password, type, auth_type, created_at, updated_at) FROM stdin;
1	manish@idifysolutions.com	manish	\N	user	2012-09-06 06:36:19.746874	2012-09-06 06:36:19.746874
2	jhai@hailabs.com	test	\N	user	2012-10-03 05:46:02.309206	2012-10-03 05:46:02.309206
\.


--
-- Name: audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY audits
    ADD CONSTRAINT audits_pkey PRIMARY KEY (id);


--
-- Name: automated_db_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY automated_db_backups
    ADD CONSTRAINT automated_db_backups_pkey PRIMARY KEY (id);


--
-- Name: devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: file_upolads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY file_upolads
    ADD CONSTRAINT file_upolads_pkey PRIMARY KEY (id);


--
-- Name: images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: mandatory_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mandatory_fields
    ADD CONSTRAINT mandatory_fields_pkey PRIMARY KEY (id);


--
-- Name: patient_user_defined_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY patient_user_defined_data
    ADD CONSTRAINT patient_user_defined_data_pkey PRIMARY KEY (id);


--
-- Name: patient_user_defined_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY patient_user_defined_fields
    ADD CONSTRAINT patient_user_defined_fields_pkey PRIMARY KEY (id);


--
-- Name: patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: slitlamps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY slitlamps
    ADD CONSTRAINT slitlamps_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- PostgreSQL database dump complete
--

